#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests


def get(url):
    #print(urlopen(url).read())
    requests.get(url)


if __name__ == "__main__":
#    get("http://localhost:8000/")
    pass
