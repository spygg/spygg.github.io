#include "callpython.h"

#include <QCoreApplication>
#include <QProcess>
#include <QDebug>
#include <QFile>
#include <QResource>



int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
//    qDebug() << QResource::registerResource("D:/code/workcode/qtCallPython/res.rcc");
#if 0
    //方法一:调用pyhton.exe
    QFile::copy(":/DemoPython.py", "DemoPython.py");
    QStringList args;
    args.append("DemoPython.py");
    QProcess::execute(QString("Python.exe"), args);

    QFile::setPermissions("DemoPython.py", QFile::ReadOther | QFile::WriteOther);
    QFile::remove("DemoPython.py");

#endif

    //方法二: 执行代码段
    CallPython cp;

    cp.execSimpleString("print('Hello Python Call From Qt!')");

    cp.loadPythonFile(":DemoPython.py");
    cp.callMethod("PrintHello", QVariantList() << "Call Python from Qt Interface");

    QVariant ret = cp.callMethod("add", QVariantList() << 3.1 << 4);
    qDebug() << ret.toDouble();

    CallPython xx;
    xx.loadPythonFile(":FilePython.py");
    xx.callMethod("get", QVariantList() << "http://localhost:8000/");

    return a.exec();
}
