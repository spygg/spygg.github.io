# -*- coding: utf-8 -*-


from PyQt5.QtCore import pyqtSlot as Slot
from PyQt5 import QtCore
from PyQt5.QtCore import QObject
from PyQt5 import QtWidgets


class ClassPython(QObject):
    def __init__(self):
        print("Hello ClassPython");

def add(a, b):
    return a + b

if __name__ == '__main__':
    add(3, 5)
    print("Main run");
