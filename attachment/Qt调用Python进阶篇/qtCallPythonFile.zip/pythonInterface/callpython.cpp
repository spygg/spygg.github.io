#include "callpython.h"

#include <QFile>
#include <QDebug>

CallPython::CallPython():
    m_bInitOk(false)
{
    m_object = NULL;
    Py_Initialize();   //初始化

    m_bInitOk = Py_IsInitialized();
}

CallPython::~CallPython()
{
    Py_Finalize();
}

PyObject *CallPython::getMainModule()
{
    PyObject *dict = PyImport_GetModuleDict();
    return PyDict_GetItemString(dict, "__main__");
}

PyObject *CallPython::lookupObject(PyObject* module, const QString& name)
{
    QStringList l = name.split('.');
    PyObject* p = module;

    QByteArray b;
    for (QStringList::ConstIterator i = l.begin(); i!=l.end() && p; ++i) {
        b = QStringToPythonEncoding(*i);
        if (PyDict_Check(p)) {
            p = PyDict_GetItemString(p, b.data());
        }
        else {
            p = PyObject_GetAttrString(p, b.data());
        }
    }
    PyErr_Clear();
    return p;
}


PyObject* CallPython::lookupCallable(PyObject* module, const QString& name)
{
    PyObject* p = lookupObject(module, name);
    if (p) {
        if (PyCallable_Check(p)) {
            return p;
        }
    }
    PyErr_Clear();
    return NULL;
}

int CallPython::execSimpleString(QString ps)
{
    return PyRun_SimpleString(ps.toUtf8().constData());
}

QVariant CallPython::callMethod(const char *method, const QVariantList& args)
{
    if(!m_object){
        qDebug() << "请先加载文件";
        return -1;
    }

    PyObject* methodobj = PyObject_GetAttrString(m_object, method);

    if(methodobj){
        PyObject* r = callAndReturnPyObject(methodobj, args);

        if(r){
            return PyConvert::PyObjToQVariant(r);
        }
        else{
            qDebug() << QString("调用函数 %1 时发生了异常!").arg(method);
//            handleError();
        }
    }
    else{
        qDebug() << QString("没有找到函数: %1 ").arg(method);
    }

    PyErr_Clear();
    return QVariant();
}

PyObject* CallPython::callAndReturnPyObject(PyObject* callable, const QVariantList& args)
{
    PyObject* result = NULL;

    if (callable) {
        bool err = false;
        PyObject* pargs;
        int count = args.size();
        if (count > 0 ) { // create empty tuple if kwargs are given
            pargs = PyTuple_New(count);

            // transform QVariant arguments to Python
            for (int i = 0; i < count; i++) {
                PyObject* arg = PyConvert::QVariantToPyObject(args.at(i));
                if (arg) {
                    // steals reference, no unref
                    PyTuple_SetItem(pargs, i,arg);
                }
                else {
                    err = true;
                    break;
                }
            }
        }
        if (!err) {
            // do a direct call if we have no keyword arguments
            PyErr_Clear();
            result = PyObject_CallObject(callable, pargs);
        }
    }

    return result;
}

int CallPython::loadPythonFile(QString fileName)
{
    QFile file(fileName);
    if(file.open(QIODevice::ReadOnly)){
        QByteArray data = file.readAll();
        if (m_object){
            Py_DECREF(m_object);
        }

        m_object = getMainModule();
        PyObject *code = compileSource(fileName, data);
        if (code) {
            evalCode(m_object, code);
        }
    }

    return 0;
}


QVariant CallPython::evalCode(PyObject* object, PyObject* pycode)
{
    QVariant result;

    if (pycode) {
        PyObject* dict = NULL;
        PyObject* globals = NULL;

        if (PyModule_Check(object)) {
            dict = PyModule_GetDict(object);
            globals = dict;
        } else if (PyDict_Check(object)) {
            dict = object;
            globals = dict;
        }
        else{
            dict = PyObject_GetAttrString(object, "__dict__");
            globals = PyObject_GetAttrString(PyImport_ImportModule(PyString_AS_STRING(PyObject_GetAttrString(object, "__module__"))),"__dict__");
        }

        PyObject* r = NULL;

        if (dict) {
#ifdef PY3K
            r = PyEval_EvalCode(pycode, globals, dict);
#else
            r = PyEval_EvalCode((PyCodeObject*)pycode, globals, dict);
#endif
        }
        if (r) {
            Py_DECREF(r);
        }
        else {
            handleError();
        }
    }
    else {
        handleError();
    }
    return result;
}

void CallPython::handleError()
{
    PyErr_Print();
}


PyObject *CallPython::compileSource(const QString& path, const QByteArray& data)
{
    PyObject *code;

#ifdef PY3K
    PyObject* filename = PyConvert::QStringToPyObject(path);
    code = Py_CompileStringObject(data.data(), filename,
                                  Py_file_input, NULL, -1);
    Py_DECREF(filename);
#else
    code = Py_CompileString(data.data(), QStringToPythonConstCharPointer(path),
                            Py_file_input);
#endif
    return code;
}
