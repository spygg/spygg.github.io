#ifndef CALLPYTHON_H
#define CALLPYTHON_H

#include "pyconvert.h"




class CallPython
{
public:

    explicit CallPython();
    ~CallPython();

public:
    int execSimpleString(QString ps);
    int loadPythonFile(QString fileName);
    QVariant callMethod(const char *method, const QVariantList& args = QVariantList());

private:
    bool m_bInitOk;

    PyObject* m_object;
private:
    PyObject *getMainModule();
    void handleError();
    QVariant evalCode(PyObject *object, PyObject *pycode);
    PyObject *compileSource(const QString &path, const QByteArray &data);

    PyObject *lookupObject(PyObject *module, const QString &name);
    PyObject *lookupCallable(PyObject *module, const QString &name);
    PyObject *callAndReturnPyObject(PyObject *callable, const QVariantList &args);



};

#endif // CALLPYTHON_H
