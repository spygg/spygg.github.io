#include "pyconvert.h"

PyObject* PyConvert::QVariantToPyObject(const QVariant& v)
{
    if (!v.isValid()) {
        Py_INCREF(Py_None);
        return Py_None;
    }

    PyObject* obj = NULL;
    //  if (v.userType() >= QMetaType::User && !PythonQt::priv()->isPythonQtAnyObjectPtrMetaId(v.userType())) {
    //    // try the slower way, which supports more conversions, e.g. QList<QObject*>
    //    const PythonQtMethodInfo::ParameterInfo& info = PythonQtMethodInfo::getParameterInfoForMetaType(v.userType());
    //    obj = ConvertQtValueToPython(info, v.constData());
    //  } else {
    //    // try the quick way to convert it, since it is a built-in type:

    //  }

    obj = convertQtValueToPythonInternal(v.userType(), (void*)v.constData());
    return obj;
}


PyObject* PyConvert::convertQtValueToPythonInternal(int type, const void* data)
{
    switch (type) {
    case QMetaType::Void:
        Py_INCREF(Py_None);
        return Py_None;
    case QMetaType::Char:
        return PyInt_FromLong(*((char*)data));
    case QMetaType::UChar:
        return PyInt_FromLong(*((unsigned char*)data));
    case QMetaType::Short:
        return PyInt_FromLong(*((short*)data));
    case QMetaType::UShort:
        return PyInt_FromLong(*((unsigned short*)data));
    case QMetaType::Long:
        return PyInt_FromLong(*((long*)data));
    case QMetaType::ULong:
        // does not fit into simple int of python
        return PyLong_FromUnsignedLong(*((unsigned long*)data));
    case QMetaType::Bool:
        return PyConvert::GetPyBool(*((bool*)data));
    case QMetaType::Int:
        return PyInt_FromLong(*((int*)data));
    case QMetaType::UInt:
        // does not fit into simple int of python
        return PyLong_FromUnsignedLong(*((unsigned int*)data));
    case QMetaType::QChar:
        return PyInt_FromLong(*((unsigned short*)data));
    case QMetaType::Float:
        return PyFloat_FromDouble(*((float*)data));
    case QMetaType::Double:
        return PyFloat_FromDouble(*((double*)data));
    case QMetaType::LongLong:
        return PyLong_FromLongLong(*((qint64*)data));
    case QMetaType::ULongLong:
        return PyLong_FromUnsignedLongLong(*((quint64*)data));
        // implicit conversion from QByteArray to str has been removed:
        //case QMetaType::QByteArray: {
        //  QByteArray* v = (QByteArray*) data;
        //  return PyBytes_FromStringAndSize(*v, v->size());
        //                            }
    case QMetaType::QVariantHash:
        return QVariantHashToPyObject(*((QVariantHash*)data));
    case QMetaType::QVariantMap:
        return QVariantMapToPyObject(*((QVariantMap*)data));
    case QMetaType::QVariantList:
        return QVariantListToPyObject(*((QVariantList*)data));
    case QMetaType::QString:
        return QStringToPyObject(*((QString*)data));
    case QMetaType::QStringList:
        return QStringListToPyObject(*((QStringList*)data));

        //  case PythonQtMethodInfo::Variant:
        //#if QT_VERSION >= 0x040800
        //  case QMetaType::QVariant:
        //#endif
        //    return QVariantToPyObject(*((QVariant*)data));
        //  case QMetaType::QObjectStar:
        //#if( QT_VERSION < QT_VERSION_CHECK(5,0,0) )
        //  case QMetaType::QWidgetStar:
        //#endif
        //    return PythonQt::priv()->wrapQObject(*((QObject**)data));

    default:
        break;
    }

    Py_INCREF(Py_None);
    return Py_None;
}


PyObject* PyConvert::GetPyBool(bool val)
{
    PyObject* r = val?Py_True:Py_False;
    Py_INCREF(r);
    return r;
}

PyObject* PyConvert::QVariantMapToPyObject(const QVariantMap& m)
{
    return mapToPython<QVariantMap>(m);
}

template <typename Map>
PyObject* PyConvert::mapToPython (const Map& m)
{
    PyObject* result = PyDict_New();
    typename Map::const_iterator t = m.constBegin();
    PyObject* key;
    PyObject* val;
    for (;t!=m.constEnd();t++) {
        key = QStringToPyObject(t.key());
        val = QVariantToPyObject(t.value());
        PyDict_SetItem(result, key, val);
        Py_DECREF(key);
        Py_DECREF(val);
    }

    return result;
}


PyObject* PyConvert::QVariantHashToPyObject(const QVariantHash& m)
{
    return mapToPython<QVariantHash>(m);
}

PyObject* PyConvert::QVariantListToPyObject(const QVariantList& l)
{
    PyObject* result = PyTuple_New(l.count());
    int i = 0;
    QVariant v;
    Q_FOREACH (v, l) {
        PyTuple_SET_ITEM(result, i, QVariantToPyObject(v));
        i++;
    }
    // why is the error state bad after this?
    PyErr_Clear();
    return result;
}


PyObject* PyConvert::QStringToPyObject(const QString& str)
{
    if (str.isNull()) {
        return PyString_FromString("");
    }
    else {
        return PyUnicode_DecodeUTF16((const char*)str.utf16(), str.length()*2, NULL, NULL);
    }
}


PyObject* PyConvert::QStringListToPyObject(const QStringList& list)
{
    PyObject* result = PyTuple_New(list.count());
    int i = 0;
    QString str;
    Q_FOREACH (str, list) {
        PyTuple_SET_ITEM(result, i, QStringToPyObject(str));
        i++;
    }
    // why is the error state bad after this?
    PyErr_Clear();
    return result;
}


/////////////////////////////////////////////////////////////////////////////////

QVariant PyConvert::PyObjToQVariant(PyObject* val, int type)
{
    QVariant v;
    bool ok = true;

    if (type == -1
        #if QT_VERSION >= 0x040800
            || type == QMetaType::QVariant
        #endif
            ) {
        // no special type requested
        if (PyBytes_Check(val)) {
#ifdef PY3K
            // In Python 3, it is a ByteArray
            type = QVariant::ByteArray;
#else
            // In Python 2, we need to use String, since it might be a string
            type = QVariant::String;
#endif
        } else if (PyUnicode_Check(val)) {
            type = QVariant::String;
        } else if (val == Py_False || val == Py_True) {
            type = QVariant::Bool;
#ifndef PY3K
        } else if (PyObject_TypeCheck(val, &PyInt_Type)) {
            type = QVariant::Int;
#endif
        } else if (PyLong_Check(val)) {
            // return int if the value fits into that range,
            // otherwise it would not be possible to get an int from Python 3
            qint64 d = PyLong_AsLongLong(val);
            if (d > std::numeric_limits<int>::max() ||
                    d < std::numeric_limits<int>::min()) {
                type = QVariant::LongLong;
            } else {
                type = QVariant::Int;
            }
        } else if (PyFloat_Check(val)) {
            type = QVariant::Double;
        }
        //    else if (PyObject_TypeCheck(val, &PythonQtInstanceWrapper_Type)) {
        //      PythonQtInstanceWrapper* wrap = (PythonQtInstanceWrapper*)val;
        //      // c++ wrapper, check if the class names of the c++ objects match
        //      if (wrap->classInfo()->isCPPWrapper()) {
        //        if (wrap->classInfo()->metaTypeId()>0) {
        //          // construct a new variant from the C++ object if it has a meta type (this will COPY the object!)
        //          v = QVariant(wrap->classInfo()->metaTypeId(), wrap->_wrappedPtr);
        //        } else {
        //          // TODOXXX we could as well check if there is a registered meta type for "classname*", so that we may pass
        //          // the pointer here...
        //          // is this worth anything? we loose the knowledge of the cpp object type
        //          v = qVariantFromValue(wrap->_wrappedPtr);
        //        }
        //      } else {
        //        // this gives us a QObject pointer
        //        QObject* myObject = wrap->_obj;
        //        v = qVariantFromValue(myObject);
        //      }
        //      return v;
        //    }
        else if (val == Py_None) {
            // none is invalid
            type = QVariant::Invalid;
        } else if (PyDict_Check(val)) {
            type = QVariant::Map;
        } else if (PyList_Check(val) || PyTuple_Check(val) || PySequence_Check(val)) {
            type = QVariant::List;
        }
        //    else {
        //      // transport the Python objects directly inside of QVariant:
        //      v = PythonQtObjectPtr(val).toVariant();
        //      return v;
        //    }
    }
    // special type request:
    switch (type) {
    case QVariant::Invalid:
        return v;
        break;
    case QVariant::Int:
    {
        int d = PyObjGetInt(val, false, ok);
        if (ok) return QVariant(d);
    }
        break;
    case QVariant::UInt:
    {
        int d = PyObjGetInt(val, false,ok);
        if (ok) v = QVariant((unsigned int)d);
    }
        break;
    case QVariant::Bool:
    {
        int d = PyObjGetBool(val,false,ok);
        if (ok) v =  QVariant((bool)(d!=0));
    }
        break;
    case QVariant::Double:
    {
        double d = PyObjGetDouble(val,false,ok);
        if (ok) v =  QVariant(d);
        break;
    }
    case QMetaType::Float:
    {
        float d = (float) PyObjGetDouble(val,false,ok);
        if (ok) v =  qVariantFromValue(d);
        break;
    }
    case QMetaType::Long:
    {
        long d = (long) PyObjGetLongLong(val,false,ok);
        if (ok) v =  qVariantFromValue(d);
        break;
    }
    case QMetaType::ULong:
    {
        unsigned long d = (unsigned long) PyObjGetLongLong(val,false,ok);
        if (ok) v =  qVariantFromValue(d);
        break;
    }
    case QMetaType::LongLong:
    {
        qint64 d = PyObjGetLongLong(val, false, ok);
        if (ok) v =  qVariantFromValue(d);
    }
        break;
    case QMetaType::ULongLong:
    {
        quint64 d = PyObjGetULongLong(val, false, ok);
        if (ok) v =  qVariantFromValue(d);
    }
        break;
    case QMetaType::Short:
    {
        short d = (short) PyObjGetInt(val,false,ok);
        if (ok) v =  qVariantFromValue(d);
        break;
    }
    case QMetaType::UShort:
    {
        unsigned short d = (unsigned short) PyObjGetInt(val,false,ok);
        if (ok) v =  qVariantFromValue(d);
        break;
    }
    case QMetaType::Char:
    {
        char d = (char) PyObjGetInt(val,false,ok);
        if (ok) v =  qVariantFromValue(d);
        break;
    }
    case QMetaType::UChar:
    {
        unsigned char d = (unsigned char) PyObjGetInt(val,false,ok);
        if (ok) v =  qVariantFromValue(d);
        break;
    }

    case QVariant::ByteArray:
    {
        bool ok;
#ifdef PY3K
        v = QVariant(PyObjGetBytes(val, false, ok));
#else
        v = QVariant(PyObjGetString(val, false, ok));
#endif
    }
    case QVariant::String:
    {
        bool ok;
        v = QVariant(PyObjGetString(val, false, ok));
    }
        break;

    case QVariant::Map:
        pythonToMapVariant<QVariantMap>(val, v);
        break;
    case QVariant::Hash:
        pythonToMapVariant<QVariantHash>(val, v);
        break;
    case QVariant::List:
    {
        bool isListOrTuple = PyList_Check(val) || PyTuple_Check(val);
        if (isListOrTuple || PySequence_Check(val)) {
            //      if (!isListOrTuple && _pythonSequenceToQVariantListCB) {
            //        // Only call this if we don't have a tuple or list.
            //        QVariant result = (*_pythonSequenceToQVariantListCB)(val);
            //        if (result.isValid()) {
            //          return result;
            //        }
            //      }
            int count = PySequence_Size(val);
            if (count >= 0) {
                // only get items if size is valid (>= 0)
                QVariantList list;
                PyObject* value;
                for (int i = 0; i < count; i++) {
                    value = PySequence_GetItem(val, i);
                    list.append(PyObjToQVariant(value, -1));
                    Py_XDECREF(value);
                }
                v = list;
            }
        }
    }
        break;
    case QVariant::StringList:
    {
        bool ok;
        QStringList l = PyObjToStringList(val, false, ok);
        if (ok) {
            v = l;
        }
    }
        break;

    default:
        //    if (PyObject_TypeCheck(val, &PythonQtInstanceWrapper_Type)) {
        //      PythonQtInstanceWrapper* wrap = (PythonQtInstanceWrapper*)val;
        //      if (wrap->classInfo()->isCPPWrapper() && wrap->classInfo()->metaTypeId() == type) {
        //        // construct a new variant from the C++ object if it has the same meta type
        //        v = QVariant(type, wrap->_wrappedPtr);
        //      } else {
        //        // Try to convert the object to a QVariant based on the typeName
        //        bool ok;
        //        bool isPtr = false;
        //        QByteArray typeName = QMetaType::typeName(type);
        //        if (typeName.endsWith("*")) {
        //          isPtr = true;
        //          typeName.truncate(typeName.length() - 1);
        //        }
        //        void* object = castWrapperTo(wrap, typeName, ok);
        //        if (ok) {
        //          if (isPtr) {
        //            v = QVariant(type, &object);
        //          }
        //          else {
        //            v = QVariant(type, object);
        //          }
        //        }
        //      }
        //    } else if (type >= QVariant::UserType) {
        //      // not an instance wrapper, but there might be other converters
        //      // Maybe we have a special converter that is registered for that type:
        //      PyConvertertPythonToMetaTypeCB* converter = _pythonToMetaTypeConverters.value(type);
        //      if (converter) {
        //        // allocate a default object of the needed type:
        //        v = QVariant(type, (const void*)NULL);
        //        // now call the converter, passing the internal object of the variant
        //        ok = (*converter)(val, (void*)v.constData(), type, true);
        //        if (!ok) {
        //          v = QVariant();
        //        }
        //      }
        //      else {
        //        // try QList<AnyObject*>...
        //        const PythonQtMethodInfo::ParameterInfo& info = PythonQtMethodInfo::getParameterInfoForMetaType(type);
        //        if (info.isQList && (info.innerNamePointerCount == 1)) {
        //          // allocate a default object of the needed type:
        //          v = QVariant(type, (const void*)NULL);
        //          ok = ConvertPythonListToQListOfPointerType(val, (QList<void*>*)v.constData(), info, true);
        //          if (!ok) {
        //            v = QVariant();
        //          }
        //        }
        //      }
        //    }
        break;
    }
    return v;
}



int PyConvert::PyObjGetInt(PyObject* val, bool strict, bool &ok)
{
    int d = 0;
    ok = true;
    if (val->ob_type == &PyInt_Type) {
        d = PyInt_AS_LONG(val);
    }
    else if (!strict) {
        if (PyObject_TypeCheck(val, &PyInt_Type)) {
            // support for derived int classes, e.g. for our enums
            d = PyInt_AS_LONG(val);
        }
        else if (val->ob_type == &PyFloat_Type) {
            d = floor(PyFloat_AS_DOUBLE(val));
        }
        else if (val->ob_type == &PyLong_Type) {
            // handle error on overflow!
            d = PyLong_AsLong(val);
        }
        else if (val == Py_False) {
            d = 0;
        }
        else if (val == Py_True) {
            d = 1;
        }
        else {
            PyErr_Clear();
            // PyInt_AsLong will try conversion to an int if the object is not an int:
            d = PyInt_AsLong(val);
            if (PyErr_Occurred()) {
                ok = false;
                PyErr_Clear();
            }
        }
    }
    else {
        ok = false;
    }

    return d;
}

qint64 PyConvert::PyObjGetLongLong(PyObject* val, bool strict, bool &ok)
{
    qint64 d = 0;
    ok = true;
#ifndef PY3K
    if (val->ob_type == &PyInt_Type) {
        d = PyInt_AS_LONG(val);
    }
    else
#endif
        if (val->ob_type == &PyLong_Type) {
            d = PyLong_AsLongLong(val);
        }
        else if (!strict) {
            if (PyObject_TypeCheck(val, &PyInt_Type)) {
                // support for derived int classes, e.g. for our enums
                d = PyInt_AS_LONG(val);
            }
            else if (val->ob_type == &PyFloat_Type) {
                d = floor(PyFloat_AS_DOUBLE(val));
            }
            else if (val == Py_False) {
                d = 0;
            }
            else if (val == Py_True) {
                d = 1;
            }
            else {
                PyErr_Clear();
                // PyLong_AsLongLong will try conversion to an int if the object is not an int:
                d = PyLong_AsLongLong(val);
                if (PyErr_Occurred()) {
                    ok = false;
                    PyErr_Clear();
                }
            }
        }
        else {
            ok = false;
        }
    return d;
}

quint64 PyConvert::PyObjGetULongLong(PyObject* val, bool strict, bool &ok) {
    quint64 d = 0;
    ok = true;
#ifndef PY3K
    if (Py_TYPE(val) == &PyInt_Type) {
        d = PyInt_AS_LONG(val);
    }
    else
#endif
        if (Py_TYPE(val) == &PyLong_Type) {
            d = PyLong_AsLongLong(val);
        } else if (!strict) {
            if (PyObject_TypeCheck(val, &PyInt_Type)) {
                // support for derived int classes, e.g. for our enums
                d = PyInt_AS_LONG(val);
            }
            else if (val->ob_type == &PyFloat_Type) {
                d = floor(PyFloat_AS_DOUBLE(val));
            }
            else if (val == Py_False) {
                d = 0;
            }
            else if (val == Py_True) {
                d = 1;
            }
            else {
                PyErr_Clear();
                // PyLong_AsLongLong will try conversion to an int if the object is not an int:
                d = PyLong_AsLongLong(val);
                if (PyErr_Occurred()) {
                    PyErr_Clear();
                    ok = false;
                }
            }
        }
        else {
            ok = false;
        }
    return d;
}

double PyConvert::PyObjGetDouble(PyObject* val, bool strict, bool &ok)
{
    double d = 0;
    ok = true;
    if (val->ob_type == &PyFloat_Type) {
        d = PyFloat_AS_DOUBLE(val);
    }
    else if (!strict) {
#ifndef PY3K
        if (PyObject_TypeCheck(val, &PyInt_Type)) {
            d = PyInt_AS_LONG(val);
        } else
#endif
            if (PyLong_Check(val)) {
                d = static_cast<double>(PyLong_AsLongLong(val));
            }
            else if (val == Py_False) {
                d = 0;
            }
            else if (val == Py_True) {
                d = 1;
            }
            else {
                PyErr_Clear();
                // PyFloat_AsDouble will try conversion to a double if the object is not a float:
                d = PyFloat_AsDouble(val);
                if (PyErr_Occurred()) {
                    PyErr_Clear();
                    ok = false;
                }
            }
    }
    else {
        ok = false;
    }

    return d;
}

bool PyConvert::PyObjGetBool(PyObject* val, bool strict, bool &ok)
{
    bool d = false;
    ok = false;
    if (val == Py_False) {
        d = false;
        ok = true;
    }
    else if (val == Py_True) {
        d = true;
        ok = true;
    }
    else if (!strict) {
        int result = PyObject_IsTrue(val);
        d = (result == 1);
        // the result is -1 if an error occurred, handle this:
        ok = (result != -1);
    }

    return d;
}

QByteArray PyConvert::PyObjGetBytes(PyObject* val, bool /*strict*/, bool& ok)
{
    // TODO: support buffer objects in general
    QByteArray r;
    ok = true;
    if (PyBytes_Check(val)) {
        r = QByteArray(PyBytes_AS_STRING(val), PyBytes_GET_SIZE(val));
    }
    else {
        ok = false;
    }

    return r;
}

QString PyConvert::PyObjGetString(PyObject* val, bool strict, bool& ok)
{
    QString r;
    ok = true;
#ifndef PY3K
    // in Python 3, we don't want to convert to QString, since we don't know anything about the encoding
    // in Python 2, we assume the default for str is latin-1
    if (val->ob_type == &PyBytes_Type) {
        r = QString::fromLatin1(PyBytes_AS_STRING(val));
    } else
#endif
        if (PyUnicode_Check(val)) {
#ifdef PY3K
            r = QString::fromUtf8(PyUnicode_AsUTF8(val));
#else
            PyObject *ptmp = PyUnicode_AsUTF8String(val);
            if(ptmp) {
                r = QString::fromUtf8(PyString_AS_STRING(ptmp));
                Py_DECREF(ptmp);
            }
#endif
        }
        else if (!strict) {
            PyObject* str =  PyObject_Str(val);
            if (str) {
#ifdef PY3K
                r = QString::fromUtf8(PyUnicode_AsUTF8(str));
#else
                r = QString(PyString_AS_STRING(str));
#endif
                Py_DECREF(str);
            }
            else {
                ok = false;
            }
        }
        else {
            ok = false;
        }
    return r;
}


template <typename Map>
void PyConvert::pythonToMapVariant(PyObject* val, QVariant& result)
{
    if (PyMapping_Check(val)) {
        Map map;
        PyObject* items = PyMapping_Items(val);
        if (items) {
            int count = PyList_Size(items);
            PyObject* value;
            PyObject* key;
            PyObject* tuple;
            for (int i = 0;i<count;i++) {
                tuple = PyList_GetItem(items,i);
                key = PyTuple_GetItem(tuple, 0);
                value = PyTuple_GetItem(tuple, 1);
                map.insert(PyObjGetString(key), PyObjToQVariant(value,-1));
            }
            Py_DECREF(items);
            result = map;
        }
    }
}


QStringList PyConvert::PyObjToStringList(PyObject* val, bool strict, bool& ok)
{
    QStringList v;
    ok = false;
    // if we are strict, we do not want to convert a string to a stringlist
    // (strings in python are detected to be sequences)
    if (strict &&
            (val->ob_type == &PyBytes_Type ||
             PyUnicode_Check(val))) {
        return v;
    }
    if (PySequence_Check(val)) {
        int count = PySequence_Size(val);
        if (count >= 0) {
            for (int i = 0;i<count;i++) {
                PyObject* value = PySequence_GetItem(val,i);
                v.append(PyObjGetString(value,false,ok));
                Py_XDECREF(value);
            }
            ok = true;
        }
    }
    return v;
}
