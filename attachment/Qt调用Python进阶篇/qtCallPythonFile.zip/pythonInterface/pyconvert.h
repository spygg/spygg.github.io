#ifndef PYCONVERT_H
#define PYCONVERT_H


#include <QVariantMap>
#include <QString>
#include <QList>
#include <vector>
#include <QObject>

#undef slots
#include <cmath>
#include <Python.h>
#define slots Q_SLOTS


#ifndef PY3K
#if PY_MAJOR_VERSION >= 3
#define PY3K
// Helper defines to facilitate porting
#define PyString_FromString PyUnicode_FromString
#define PyString_AS_STRING  PyUnicode_AsUTF8
#define PyString_AsString   PyUnicode_AsUTF8
#define PyString_FromFormat PyUnicode_FromFormat
#define PyString_Check      PyUnicode_Check

#define PyInt_Type     PyLong_Type
#define PyInt_FromLong PyLong_FromLong
#define PyInt_AS_LONG  PyLong_AS_LONG
#define PyInt_Check    PyLong_Check
#define PyInt_AsLong   PyLong_AsLong

#else
// Defines to use Python 3 names in Python 2 code
#define PyBytes_Type      PyString_Type
#define PyBytes_Check     PyString_Check
#define PyBytes_AS_STRING PyString_AS_STRING
#define PyBytes_AsString  PyString_AsString
#define PyBytes_GET_SIZE  PyString_GET_SIZE
#define PyBytes_FromStringAndSize PyString_FromStringAndSize
#endif

#ifdef PY3K
#define QStringToPythonConstCharPointer(arg) ((arg).toUtf8().constData())
#define QStringToPythonCharPointer(arg) ((arg).toUtf8().data())
#define QStringToPythonEncoding(arg) ((arg).toUtf8())
#else
#define QStringToPythonConstCharPointer(arg) ((arg).toLatin1().constData())
#define QStringToPythonCharPointer(arg) ((arg).toLatin1().data())
#define QStringToPythonEncoding(arg) ((arg).toLatin1())
#endif

#endif

class PyConvert
{
public:
    //! get a ref counted True or False Python object
    static PyObject* GetPyBool(bool val);

    //! converts QString to Python string (unicode!)
    static PyObject* QStringToPyObject(const QString& str);

    //! converts QStringList to Python tuple
    static PyObject* QStringListToPyObject(const QStringList& list);

    //! converts QStringList to Python list
    static PyObject* QStringListToPyList(const QStringList& list);

      //! get string representation of py object
    static QString PyObjGetRepresentation(PyObject* val);

    //! get string value from py object
    static QString PyObjGetString(PyObject* val) { bool ok; QString s = PyObjGetString(val, false, ok); return s; }
    //! get string value from py object
    static QString PyObjGetString(PyObject* val, bool strict, bool &ok);
    //! get bytes from py object
    static QByteArray PyObjGetBytes(PyObject* val, bool strict, bool &ok);
    //! get int from py object
    static int     PyObjGetInt(PyObject* val, bool strict, bool &ok);
    //! get int64 from py object
    static qint64  PyObjGetLongLong(PyObject* val, bool strict, bool &ok);
    //! get int64 from py object
    static quint64  PyObjGetULongLong(PyObject* val, bool strict, bool &ok);
    //! get double from py object
    static double  PyObjGetDouble(PyObject* val, bool strict, bool &ok);
    //! get bool from py object
    static bool    PyObjGetBool(PyObject* val, bool strict, bool &ok);

    //! create a string list from python sequence
    static QStringList PyObjToStringList(PyObject* val, bool strict, bool& ok);

    //! convert python object to qvariant, if type is given it will try to create a qvariant of that type, otherwise
    //! it will guess from the python type
    static QVariant PyObjToQVariant(PyObject* val, int type = -1);

    //! convert QVariant from PyObject
    static PyObject* QVariantToPyObject(const QVariant& v);

    static PyObject* QVariantHashToPyObject(const QVariantHash& m);
    static PyObject* QVariantMapToPyObject(const QVariantMap& m);
    static PyObject* QVariantListToPyObject(const QVariantList& l);

    //! get human readable string from CPP object (when the metatype is known)
    static QString CPPObjectToString(int type, const void* data);

    //! converts the Qt parameter given in \c data, interpreting it as a \c type registered qvariant/meta type, into a Python object,
    static PyObject* convertQtValueToPythonInternal(int type, const void* data);

    //! creates a copy of given object, using the QMetaType
    static PyObject* createCopyFromMetaType( int type, const void* object );


    static bool      convertToPythonQtObjectPtr(PyObject* obj, void* /* PythonQtObjectPtr* */ outPtr, int /*metaTypeId*/, bool /*strict*/);
    static PyObject* convertFromPythonQtObjectPtr(const void* /* PythonQtObjectPtr* */ inObject, int /*metaTypeId*/);
    static bool      convertToPythonQtSafeObjectPtr(PyObject* obj, void* /* PythonQtObjectPtr* */ outPtr, int /*metaTypeId*/, bool /*strict*/);
    static PyObject* convertFromPythonQtSafeObjectPtr(const void* /* PythonQtObjectPtr* */ inObject, int /*metaTypeId*/);
    static bool      convertToQListOfPythonQtObjectPtr(PyObject* obj, void* /* QList<PythonQtObjectPtr>* */ outList, int /*metaTypeId*/, bool /*strict*/);
    static PyObject* convertFromQListOfPythonQtObjectPtr(const void* /* QList<PythonQtObjectPtr>* */ inObject, int /*metaTypeId*/);
    static PyObject* convertFromStringRef(const void* inObject, int /*metaTypeId*/);

    //! Returns the name of the equivalent CPP type (for signals and slots)
    static QByteArray getCPPTypeName(PyObject* type);

    //! Returns if the given object is a string (or unicode string)
    static bool isStringType(PyTypeObject* type);

  protected:

    //! helper template method for conversion from Python to QVariantMap/Hash
    template <typename Map>
    static void pythonToMapVariant(PyObject* val, QVariant& result);
    //! helper template function for QVariantMapToPyObject/QVariantHashToPyObject
    template <typename Map>
    static PyObject* mapToPython (const Map& m);
};

#endif // PYCONVERT_H
