#include "dialog.h"
#include "ui_dialog.h"

#include <QFile>
#include <QDesktopWidget>
#include <QHBoxLayout>
#include <QApplication>
#include <QDebug>


Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);


    QRect rect = qApp->desktop()->availableGeometry();
    resize(rect.width(), rect.height());
    setWindowFlags((windowFlags() & ~Qt::WindowContextHelpButtonHint) | Qt::WindowMinMaxButtonsHint);

    loadFile(":/qtdesigner/qtdesigner-manual.html");
}

Dialog::~Dialog()
{
    delete ui;
}


//注意替换里面的路径为根资源路径
void Dialog::loadFile(QString fileName)
{
    QFile file(fileName);
    if(file.exists() && file.open(QIODevice::ReadOnly)){
        QByteArray html = file.readAll();
        html = html.replace("href=\"#", "tref=\"#")
                .replace("href=\"", "href=\":/qtdesigner/")
                .replace("window.onload = ", "")
                .replace("src=\"", "src=\":/qtdesigner/")
                .replace("tref=\"#", "href=\"#")
                .replace("url(", "url(:/qtdesigner/");

        ui->textBrowser->setHtml(html);
        file.close();
    }
}


void Dialog::on_textBrowser_anchorClicked(const QUrl &arg1)
{
    if(!arg1.path().isEmpty()){
        qDebug() << arg1;
        loadFile(arg1.path());
    }
}
