#include "dialog.h"
#include "ui_dialog.h"
#include <QWebSocketServer>
#include <QWebSocket>

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);


    QWebSocketServer *server = new QWebSocketServer("Spygg Server", QWebSocketServer::NonSecureMode, this);

    if(!server->listen(QHostAddress::Any, 12345)){
        qFatal("开服WS服务器失败");
    }


    connect(server, &QWebSocketServer::newConnection, this, [&, server](){
        QWebSocket *socket = server->nextPendingConnection();

        //加入队列中,便于统一管理
        sockets.append(socket);

        connect(socket, &QWebSocket::textMessageReceived, this, [=](QString message){

            socket->sendTextMessage(message);
        });


        connect(socket, &QWebSocket::disconnected, this, [&](){
            QWebSocket *sc = qobject_cast<QWebSocket *>(sender());
            sockets.removeOne(sc);

            if(sc){
                sc->close();
                sc->deleteLater();
                sc = Q_NULLPTR;
            }

        });

    });
}

Dialog::~Dialog()
{
    delete ui;
}
