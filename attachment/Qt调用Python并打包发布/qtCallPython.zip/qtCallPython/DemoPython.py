def PrintHello(name):
    print("Hello  %s" % name);


if __name__ == '__main__':
    PrintHello("Spygg");
