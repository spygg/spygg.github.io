#ifndef CALLPYTHON_H
#define CALLPYTHON_H

#include <QString>
#include <QObject>

class CallPython
{
public:

    explicit CallPython();
    ~CallPython();

    int execSimpleString(QString ps);

    bool m_bInitOk;
};

#endif // CALLPYTHON_H
