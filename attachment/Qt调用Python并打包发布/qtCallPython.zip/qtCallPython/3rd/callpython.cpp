#include "callpython.h"
#include <QDebug>
#include <QFile>

#undef slots
#include <Python.h>
#define slots Q_SLOTS


CallPython::CallPython():
    m_bInitOk(false)
{
    Py_Initialize();   //初始化

    m_bInitOk = Py_IsInitialized();

//    if(!Py_IsInitialized())
//        return;
    //导入模块
//    PyRun_SimpleString("import sys");
//    PyRun_SimpleString("sys.path.append('./')");
//    PyObject* pModule =PyImport_ImportModule("pilao.py");

//    PyRun_SimpleString("print('hello python from Qt')");
//    if(!pModule)
//        qDebug() <<"can not open python file";



}


CallPython::~CallPython()
{
    Py_Finalize();
}

int CallPython::execSimpleString(QString ps)
{
    return PyRun_SimpleString(ps.toUtf8().constData());
}

