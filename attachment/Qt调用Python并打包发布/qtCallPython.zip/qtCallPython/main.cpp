#include "callpython.h"

#include <QCoreApplication>
#include <QProcess>
#include <QDebug>
#include <QFile>


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

#if 0
    //方法一:调用pyhton.exe
    QFile::copy(":/DemoPython.py", "DemoPython.py");
    QStringList args;
    args.append("DemoPython.py");
    QProcess::execute(QString("Python.exe"), args);

    QFile::setPermissions("DemoPython.py", QFile::ReadOther | QFile::WriteOther);
    QFile::remove("DemoPython.py");

#endif

    //方法二: 执行代码段
    CallPython cp;

    cp.execSimpleString("print('Hello Python Call From Qt!')");

    QFile file(":/DemoPython.py");
    if(file.open(QIODevice::ReadOnly)){
        cp.execSimpleString(file.readAll());
    }

    return a.exec();
}
